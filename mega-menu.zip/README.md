npm install

node app.js

Open link: http://localhost:3000/
